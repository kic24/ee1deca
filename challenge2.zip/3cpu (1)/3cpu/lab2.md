See DECA web pages for the [Lab2 handout](https://intranet.ee.ic.ac.uk/t.clarke/arch/deca/images/Lab23_2_Control.pdf).

See DECA web pages for the [Spring Term lectures](https://intranet.ee.ic.ac.uk/t.clarke/arch/deca/lecs/DecaSpring23.pdf).
